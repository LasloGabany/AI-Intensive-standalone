/* AI Интенсив — поведение страницы */
(() => {
  // -------- header shadow on scroll
  const header = document.getElementById('siteHeader');
  const onScroll = () => {
    if(window.scrollY > 12) header.classList.add('scrolled');
    else header.classList.remove('scrolled');
  };
  window.addEventListener('scroll', onScroll, {passive:true});
  onScroll();

  // -------- countdown to start (May 11, 2026, 19:00 MSK)
  const startTs = new Date('2026-05-11T19:00:00+03:00').getTime();
  const tick = () => {
    const diff = Math.max(0, startTs - Date.now());
    const d = Math.floor(diff / (1000*60*60*24));
    const h = Math.floor(diff / (1000*60*60)) % 24;
    const m = Math.floor(diff / (1000*60)) % 60;
    const s = Math.floor(diff / 1000) % 60;
    const set = (id, v) => {
      const el = document.getElementById(id);
      if(el) el.textContent = String(v).padStart(2,'0');
    };
    set('cd-d', d); set('cd-h', h); set('cd-m', m); set('cd-s', s);
  };
  tick(); setInterval(tick, 1000);

  // -------- reveal on scroll
  const targets = document.querySelectorAll(
    '.pain-card, .day, .speaker, .review, .timeline li, .stack-list li, .fw-col, .testimonial-inline, .guard-card, .faq-list details, .big-quote'
  );
  targets.forEach(el => el.classList.add('reveal'));
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if(e.isIntersecting){
        e.target.classList.add('in');
        io.unobserve(e.target);
      }
    });
  }, {threshold: 0.12, rootMargin: '0px 0px -40px 0px'});
  targets.forEach(el => io.observe(el));

  // -------- form behavior
  const form = document.getElementById('regForm');
  const successBox = document.getElementById('formSuccess');

  // phone mask: keep digits, format as (xxx) xxx-xx-xx
  const phone = document.getElementById('f-phone');
  phone.addEventListener('input', () => {
    const digits = phone.value.replace(/\D/g,'').slice(0,10);
    let out = '';
    if(digits.length){
      out = '(' + digits.slice(0,3);
      if(digits.length >= 3) out += ') ';
      if(digits.length >= 4) out += digits.slice(3,6);
      if(digits.length >= 7) out += '-' + digits.slice(6,8);
      if(digits.length >= 9) out += '-' + digits.slice(8,10);
    }
    phone.value = out;
  });

  const setErr = (input, msg) => {
    const field = input.closest('.field');
    if(!field) return;
    field.classList.toggle('invalid', !!msg);
    const err = field.querySelector('.field-err');
    if(err) err.textContent = msg || '';
  };

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    let ok = true;

    const name = document.getElementById('f-name');
    if(!name.value.trim()){ setErr(name, 'Без имени мы не сможем поздороваться'); ok = false; }
    else setErr(name, '');

    const email = document.getElementById('f-email');
    const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
    if(!emailRe.test(email.value.trim())){ setErr(email, 'Похоже на опечатку — проверьте email'); ok = false; }
    else setErr(email, '');

    const agree = form.querySelector('input[name="agree"]');
    if(!agree.checked){
      // visual highlight
      agree.parentElement.style.color = '#e08a78';
      ok = false;
      setTimeout(() => { agree.parentElement.style.color = ''; }, 2000);
    }

    if(!ok) return;

    // Imitate POST to register.php — show success
    successBox.hidden = false;
    form.querySelector('button[type="submit"]').disabled = true;
    form.querySelector('button[type="submit"]').style.opacity = .6;
    successBox.scrollIntoView({behavior:'smooth', block:'center'});

    // In real life:
    // const data = new FormData(form);
    // fetch('register.php', {method:'POST', body:data}).then(...)
  });

  // -------- TWEAKS PANEL
  // 1) Listen for activate first
  const tweaks = {
    headline: 'A',
    accent: 'terracotta',
  };
  // try to read defaults from JSON marker block
  try{
    const m = document.documentElement.outerHTML.match(/EDITMODE-BEGIN[^]*?(\{[^]*?\})[^]*?EDITMODE-END/);
    if(m){ Object.assign(tweaks, JSON.parse(m[1])); }
  }catch(_e){}

  let panel = null;
  const buildPanel = () => {
    if(panel) return panel;
    panel = document.createElement('div');
    panel.className = 'tw-panel';
    panel.innerHTML = `
      <div class="tw-head">
        <h4>Tweaks</h4>
        <button class="tw-close" aria-label="Закрыть">×</button>
      </div>
      <div class="tw-body">
        <div class="tw-section">
          <div class="tw-label">Вариант заголовка (A/B/C)</div>
          <div class="tw-radio" data-tw="headline">
            <button data-val="A">А</button>
            <button data-val="B">Б</button>
            <button data-val="C">В</button>
          </div>
          <div class="tw-hint" style="margin-top:6px;font-size:11px;color:var(--ink-4)">
            А: по этапам · Б: про время · В: дерзкий
          </div>
        </div>
        <div class="tw-section">
          <div class="tw-label">Акцентный цвет</div>
          <div class="tw-swatches" data-tw="accent">
            <button class="tw-swatch" data-val="terracotta" style="background:#d97757"></button>
            <button class="tw-swatch" data-val="sage"       style="background:#7d9a7c"></button>
            <button class="tw-swatch" data-val="amber"      style="background:#cfa15a"></button>
            <button class="tw-swatch" data-val="rose"       style="background:#c66e85"></button>
            <button class="tw-swatch" data-val="indigo"     style="background:#7e84c8"></button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(panel);

    panel.querySelector('.tw-close').addEventListener('click', () => {
      panel.classList.remove('open');
      window.parent.postMessage({type:'__edit_mode_dismissed'}, '*');
    });

    panel.querySelectorAll('[data-tw="headline"] button').forEach(b => {
      b.addEventListener('click', () => {
        applyHeadline(b.dataset.val);
        persist({headline: b.dataset.val});
      });
    });
    panel.querySelectorAll('[data-tw="accent"] button').forEach(b => {
      b.addEventListener('click', () => {
        applyAccent(b.dataset.val);
        persist({accent: b.dataset.val});
      });
    });
    return panel;
  };

  const ACCENTS = {
    terracotta: {a:'#d97757', soft:'#e89678', deep:'#b85c3f', glow:'rgba(217,119,87,.18)'},
    sage:       {a:'#7d9a7c', soft:'#9bb89a', deep:'#5d7a5c', glow:'rgba(125,154,124,.18)'},
    amber:      {a:'#cfa15a', soft:'#e2bc7c', deep:'#a17c3d', glow:'rgba(207,161,90,.18)'},
    rose:       {a:'#c66e85', soft:'#dc8ea1', deep:'#9a4f64', glow:'rgba(198,110,133,.18)'},
    indigo:     {a:'#7e84c8', soft:'#9ea3da', deep:'#5d63a2', glow:'rgba(126,132,200,.18)'},
  };

  const applyHeadline = (v) => {
    document.body.dataset.headline = v;
    if(!panel) return;
    panel.querySelectorAll('[data-tw="headline"] button').forEach(b => {
      b.classList.toggle('active', b.dataset.val === v);
    });
  };
  const applyAccent = (v) => {
    const c = ACCENTS[v] || ACCENTS.terracotta;
    const r = document.documentElement.style;
    r.setProperty('--accent', c.a);
    r.setProperty('--accent-soft', c.soft);
    r.setProperty('--accent-deep', c.deep);
    r.setProperty('--accent-glow', c.glow);
    if(!panel) return;
    panel.querySelectorAll('[data-tw="accent"] button').forEach(b => {
      b.classList.toggle('active', b.dataset.val === v);
    });
  };

  const persist = (edits) => {
    Object.assign(tweaks, edits);
    try{ window.parent.postMessage({type:'__edit_mode_set_keys', edits}, '*'); }catch(_e){}
  };

  // apply persisted state on load
  applyHeadline(tweaks.headline);
  applyAccent(tweaks.accent);

  // 2) Then announce availability
  window.addEventListener('message', (e) => {
    const t = e.data && e.data.type;
    if(t === '__activate_edit_mode'){ buildPanel().classList.add('open'); }
    if(t === '__deactivate_edit_mode'){ if(panel) panel.classList.remove('open'); }
  });
  try{ window.parent.postMessage({type:'__edit_mode_available'}, '*'); }catch(_e){}
})();

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{"headline":"A","accent":"terracotta"}/*EDITMODE-END*/;
void TWEAK_DEFAULTS;

/* ============================================================
   AI FUN FACTS — particles flowing along an SVG path,
   carrying a glowing card that swaps text periodically.
   ============================================================ */
(() => {
  const svg = document.querySelector('.ff-svg');
  const path = document.getElementById('ff-path');
  const layer = document.getElementById('ffParticles');
  const card = document.getElementById('ffCard');
  const numEl = document.getElementById('ffNum');
  const txtEl = document.getElementById('ffText');
  const dots = document.querySelectorAll('.ff-dot');
  if(!svg || !path || !layer || !card) return;

  const FACTS = [
    { num: '73%',    text: 'психологов, попробовавших ИИ, бросают в первую неделю — потому что используют его как поисковик, а не как соавтора.' },
    { num: '15 мин', text: 'нужно, чтобы превратить голосовую заметку в готовый пост вашим голосом — если знать правильный режим работы.' },
    { num: '×8',     text: 'во столько раз быстрее пишется контент-план на 10 недель, когда у вас есть собственное позиционирование на руках.' },
    { num: '0',      text: 'строк кода. Всё, что нужно — уметь говорить вслух о том, что вы и так знаете лучше всех.' },
  ];

  let current = 0;
  const setFact = (i) => {
    current = (i + FACTS.length) % FACTS.length;
    card.classList.add('swap');
    setTimeout(() => {
      numEl.textContent = FACTS[current].num;
      txtEl.textContent = FACTS[current].text;
      card.classList.remove('swap');
    }, 280);
    dots.forEach((d, j) => d.classList.toggle('active', j === current));
  };
  dots.forEach((d) => d.addEventListener('click', () => setFact(parseInt(d.dataset.i,10))));

  // auto-rotate
  setInterval(() => setFact(current + 1), 5000);

  // particles
  const PARTICLES = 14;
  const particles = [];
  for(let i = 0; i < PARTICLES; i++){
    const p = document.createElement('span');
    p.className = 'ff-dot-p';
    p.style.width = (3 + Math.random()*3) + 'px';
    p.style.height = p.style.width;
    layer.appendChild(p);
    particles.push({
      el: p,
      t: Math.random(),
      speed: 0.0009 + Math.random()*0.0014, // per ms
    });
  }

  // SVG sizing helpers — translate path coords (1000x240 viewBox) to actual layer pixels
  let stageBox = layer.getBoundingClientRect();
  const sync = () => { stageBox = layer.getBoundingClientRect(); };
  window.addEventListener('resize', sync);
  sync();

  let pathLen = path.getTotalLength();

  let lastTs = performance.now();
  const tick = (ts) => {
    const dt = ts - lastTs; lastTs = ts;
    const w = stageBox.width, h = stageBox.height;
    // viewBox 0..1000 horizontally, 0..240 vertically
    for(const p of particles){
      p.t += p.speed * dt;
      if(p.t > 1){ p.t -= 1; }
      const pt = path.getPointAtLength(p.t * pathLen);
      const x = (pt.x / 1000) * w;
      const y = (pt.y / 240) * h;
      // fade in/out near edges
      const fade = Math.sin(p.t * Math.PI); // 0→1→0
      p.el.style.left = x + 'px';
      p.el.style.top  = y + 'px';
      p.el.style.opacity = (fade * 0.95).toFixed(3);
    }
    requestAnimationFrame(tick);
  };
  // start once SVG laid out
  requestAnimationFrame(() => {
    pathLen = path.getTotalLength();
    sync();
    requestAnimationFrame(tick);
  });
})();

/* ============================================================
   .business — interactive futuristic network graph
   - center node + 8 satellites
   - hover: scale, glow, light up edges, spawn flowing particles
   ============================================================ */
(() => {
  const stage = document.getElementById('netStage');
  const svg   = document.getElementById('netSvg');
  const edgesG    = document.getElementById('netEdges');
  const partsG    = document.getElementById('netParticles');
  const nodesEl   = document.getElementById('netNodes');
  if(!stage || !svg) return;

  // viewBox 1000 x 700 -> center 500,350. Place satellites on an ellipse.
  const CENTER = {x:500, y:350};
  const SATS = [
    { id:'audience',  label:'audience',  caption:'аудитория' },
    { id:'marketing', label:'marketing', caption:'маркетинг' },
    { id:'funnel',    label:'funnel',    caption:'воронка' },
    { id:'products',  label:'products',  caption:'продукты' },
    { id:'kpi',       label:'kpi',       caption:'kpi' },
    { id:'content',   label:'content',   caption:'контент' },
    { id:'team',      label:'team',      caption:'команда' },
    { id:'economics', label:'economics', caption:'экономика' },
  ];

  const RX = 380, RY = 250;
  SATS.forEach((s, i) => {
    const a = (-Math.PI/2) + (i / SATS.length) * Math.PI * 2;
    s.x = CENTER.x + Math.cos(a) * RX;
    s.y = CENTER.y + Math.sin(a) * RY;
  });

  // Build HTML nodes (positioned by % so they scale with stage)
  const placeNode = (el, x, y) => {
    el.style.left = (x / 1000 * 100) + '%';
    el.style.top  = (y / 700  * 100) + '%';
  };
  const center = document.createElement('div');
  center.className = 'net-node center';
  center.dataset.id = 'business';
  center.textContent = '.business';
  placeNode(center, CENTER.x, CENTER.y);
  nodesEl.appendChild(center);

  SATS.forEach(s => {
    const n = document.createElement('div');
    n.className = 'net-node sat';
    n.dataset.id = s.id;
    n.textContent = '.' + s.label;
    placeNode(n, s.x, s.y);
    nodesEl.appendChild(n);
  });

  // Build SVG edges: each satellite to center via a quadratic curve with slight bow
  const edges = [];
  const SVGNS = 'http://www.w3.org/2000/svg';

  SATS.forEach(s => {
    const dx = s.x - CENTER.x, dy = s.y - CENTER.y;
    const mx = (s.x + CENTER.x) / 2;
    const my = (s.y + CENTER.y) / 2;
    // perpendicular bow
    const len = Math.hypot(dx, dy);
    const nxp = -dy / len, nyp = dx / len;
    const bow = 60 * (Math.random() < .5 ? 1 : -1);
    const cx = mx + nxp * bow;
    const cy = my + nyp * bow;
    const d = `M ${CENTER.x} ${CENTER.y} Q ${cx} ${cy} ${s.x} ${s.y}`;

    const path = document.createElementNS(SVGNS, 'path');
    path.setAttribute('d', d);
    path.setAttribute('fill', 'none');
    path.setAttribute('class', 'edge');
    path.setAttribute('stroke', 'rgba(217,119,87,.18)');
    path.setAttribute('stroke-width', '1');
    edgesG.appendChild(path);

    edges.push({ id:s.id, path, len: path.getTotalLength(), particles: [] });
  });

  // Animation state
  const flows = new Set(); // ids of edges currently emitting particles

  const spawnParticle = (edge, baseSpeed) => {
    const c = document.createElementNS(SVGNS, 'circle');
    c.setAttribute('r', (1.2 + Math.random()*1.6).toFixed(2));
    c.setAttribute('class', 'net-particle');
    partsG.appendChild(c);
    edge.particles.push({
      el: c,
      t: Math.random() * 0.3,                    // staggered start
      speed: baseSpeed * (0.6 + Math.random()*0.8),
      life: 1, // 1 → 0
      decay: 0.0018 + Math.random()*0.001,        // when edge is no longer active
    });
  };

  let lastTs = performance.now();
  const animate = (ts) => {
    const dt = ts - lastTs; lastTs = ts;

    edges.forEach(edge => {
      const active = flows.has(edge.id);
      // top up particle count when active
      if(active && edge.particles.length < 4){
        spawnParticle(edge, 0.0007);
      }
      for(let i = edge.particles.length - 1; i >= 0; i--){
        const p = edge.particles[i];
        p.t += p.speed * dt;
        if(p.t > 1){ p.t -= 1; }
        if(!active){ p.life -= p.decay * dt; }
        else { p.life = Math.min(1, p.life + 0.004 * dt); }
        const pt = edge.path.getPointAtLength(p.t * edge.len);
        const fade = Math.sin(p.t * Math.PI) * p.life;
        p.el.setAttribute('cx', pt.x);
        p.el.setAttribute('cy', pt.y);
        p.el.setAttribute('opacity', Math.max(0, fade).toFixed(3));
        if(p.life <= 0){
          p.el.remove();
          edge.particles.splice(i, 1);
        }
      }
    });

    requestAnimationFrame(animate);
  };
  requestAnimationFrame(animate);

  // Hover behavior
  const allNodes = nodesEl.querySelectorAll('.net-node');
  const setHover = (id) => {
    edges.forEach(e => {
      const on = !id || e.id === id || id === 'business';
      e.path.classList.toggle('active', !!id && on);
      if(!!id && on) flows.add(e.id);
      else flows.delete(e.id);
    });
    allNodes.forEach(n => {
      const isCenter = n.dataset.id === 'business';
      const isHover  = n.dataset.id === id;
      const isLinked = !!id && (isCenter || (id === 'business') || isHover);
      n.classList.toggle('linked', isLinked && !isHover);
    });
  };

  allNodes.forEach(n => {
    n.addEventListener('mouseenter', () => setHover(n.dataset.id));
    n.addEventListener('mouseleave', () => setHover(null));
    // touch: tap toggles
    n.addEventListener('click', () => {
      const id = n.dataset.id;
      if(flows.size && [...flows][0] === id) setHover(null); else setHover(id);
    });
  });

  // Ambient: slowly cycle a single highlighted edge so the graph feels alive
  let ambientI = 0;
  let ambientTimer = setInterval(() => {
    if(flows.size) return; // user is interacting, skip
    const e = edges[ambientI % edges.length];
    flows.add(e.id);
    e.path.classList.add('active');
    setTimeout(() => {
      if(!nodesEl.querySelector('.net-node:hover')){
        flows.delete(e.id);
        e.path.classList.remove('active');
      }
    }, 1800);
    ambientI++;
  }, 2200);
})();
