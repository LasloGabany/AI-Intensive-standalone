<?php
/**
 * AI Интенсив для психологов — обработчик регистрации
 * Принимает данные с формы #regForm, валидирует, сохраняет в registrations.csv,
 * шлёт письмо организатору и подтверждение участнику.
 */

declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'method_not_allowed']);
    exit;
}

// --- helpers ---
function clean(string $s, int $max = 200): string {
    $s = trim($s);
    $s = strip_tags($s);
    return mb_substr($s, 0, $max);
}

function valid_email(string $e): bool {
    return (bool) filter_var($e, FILTER_VALIDATE_EMAIL);
}

// --- input ---
$name  = clean($_POST['name']  ?? '', 80);
$email = clean($_POST['email'] ?? '', 120);
$phone = clean($_POST['phone'] ?? '', 32);
$agree = isset($_POST['agree']);

// --- validation ---
$errors = [];
if ($name === '')                   $errors['name']  = 'Укажите имя';
if (!valid_email($email))           $errors['email'] = 'Некорректный email';
if (!$agree)                        $errors['agree'] = 'Нужно согласие на обработку данных';

// rate-limit: одна регистрация в минуту с одного IP
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$rateFile = sys_get_temp_dir() . '/ai_intensive_rl_' . md5($ip);
if (is_file($rateFile) && (time() - filemtime($rateFile)) < 60) {
    $errors['_'] = 'Слишком часто — попробуйте через минуту';
}

if (!empty($errors)) {
    http_response_code(422);
    echo json_encode(['ok' => false, 'errors' => $errors], JSON_UNESCAPED_UNICODE);
    exit;
}
@touch($rateFile);

// --- persist to CSV ---
$row = [
    date('c'),
    $ip,
    $name,
    $email,
    $phone,
    clean($_SERVER['HTTP_USER_AGENT'] ?? '', 250),
];
$csvPath = __DIR__ . '/registrations.csv';
$isNew   = !is_file($csvPath);
if (($fh = @fopen($csvPath, 'ab')) !== false) {
    if ($isNew) {
        fputcsv($fh, ['ts', 'ip', 'name', 'email', 'phone', 'ua']);
    }
    fputcsv($fh, $row);
    fclose($fh);
}

// --- notify organizer ---
$to       = 'hello@ai-intensive.ru';
$subject  = '=?UTF-8?B?' . base64_encode('Новая регистрация · AI Интенсив') . '?=';
$message  = "Имя: {$name}\nEmail: {$email}\nТелефон: +7 {$phone}\nIP: {$ip}\nВремя: " . date('Y-m-d H:i:s');
$headers  = "From: AI Интенсив <noreply@ai-intensive.ru>\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
@mail($to, $subject, $message, $headers);

// --- confirm to user ---
$userSubj  = '=?UTF-8?B?' . base64_encode('Вы зарегистрированы · 11–13 мая') . '?=';
$userBody  = "Здравствуйте, {$name}!\n\n";
$userBody .= "Ваше место на бесплатном AI Интенсиве для психологов забронировано.\n";
$userBody .= "Старт: 11 мая, 19:00 МСК · Zoom · 90 минут в день.\n\n";
$userBody .= "Ссылка на закрытый чат и первое задание — придут отдельным письмом в течение 5 минут.\n\n";
$userBody .= "До встречи!\nКоманда AI Интенсива";
@mail($email, $userSubj, $userBody, $headers);

echo json_encode(['ok' => true, 'message' => 'registered'], JSON_UNESCAPED_UNICODE);
